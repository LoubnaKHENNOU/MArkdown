##Implémentation fonction polynomiale
def poly(x):
  a= x**3
  b= (1.5)*(x**2)
  c= 6*x
  return (a-b-c+5)

print(poly(1))
